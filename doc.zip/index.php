<?php include'config/config.php'; ?>
<?php include'inc/header.php'; ?>
<?php include'inc/footer.php'; ?>
</body>
</html>  